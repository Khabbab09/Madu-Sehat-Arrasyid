
# Madu Sehat Arrasyid – 5 Halaman
Berisi:
- `index.html` (Home: banner promo, kategori, rekomendasi, produk unggulan, sosial)
- `products.html` (Produk: detail lengkap, varian, ulasan)
- `cart.html` (Keranjang: simpan & beli nanti, tampilan menarik)
- `about.html` (Tentang: sejarah, visi misi, profil, keunggulan, kontak)
- `login.html` (Login: form, error, opsi alternatif, lupa sandi, catatan SSL)

> Tambahkan gambar aset sesuai nama file (logo.png, lebah-madu.jpeg, dsb) ke folder yang sama.

Cart menggunakan `localStorage` sehingga tersinkron antar halaman pada browser yang sama.
